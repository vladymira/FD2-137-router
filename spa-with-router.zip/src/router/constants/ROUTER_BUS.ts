export const ROUTER_BUS = new class RouterBus extends EventTarget {

}();
