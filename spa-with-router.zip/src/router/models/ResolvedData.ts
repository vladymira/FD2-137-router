export type ResolvedData = Record<string, unknown>;
