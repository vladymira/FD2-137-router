export type PathParams = Record<string, string>;
