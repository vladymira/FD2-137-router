export class RedirectPath extends String {

}
